var num = 1

while (num <= 50){
    console.log("contando: ", num)
    num++
}

