var num = 10

do {

    console.log(num)
    num--
    
}while (num > 0)

