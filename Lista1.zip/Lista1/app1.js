var num = 0 
var i = 0
do {
    num = num + i
    i++
} while (i <= 200)
console.log(num)
