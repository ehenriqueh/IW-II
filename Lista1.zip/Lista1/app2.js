var num = 1 
do {
    tab = num * 4
    console.log(" 4 x", num, "=",tab)
    num++
} while (num <= 10)