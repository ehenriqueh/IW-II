

for (let i = 1; i <= 10; i++){
    resul = i % 2
    if(resul == 0){
        console.log("O numero",i,"é par")
    }else{
        console.log("O numero",i,"é impar")
    }

}